// MainActivity.kt
package com.example.alarmapp

import android.media.MediaPlayer
import android.os.Bundle
import android.util.Log

import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.alarmapp.ui.theme.AlarmAppTheme
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)

        setContent {
            AlarmAppTheme {
                var currentScreen by remember { mutableStateOf("main") }
                var alarmHour by remember { mutableStateOf("07") }
                var alarmMinute by remember { mutableStateOf("00") }
                var alarmSet by remember { mutableStateOf(false) }
                var challengeType by remember { mutableStateOf("math") }

                LaunchedEffect(Unit) {
                    while (true) {

                        delay(1000)
                        val currentTime = getCurrentTime()

                        if (alarmSet && currentTime.substring(0, 5) == "$alarmHour:$alarmMinute") {
                            if (challengeType == "math") {
                                currentScreen = "math"
                            } else {
                                // qr challenge will go here
                            }
                            alarmSet = false
                        }
                    }
                }

                when (currentScreen) {
                    "main" -> MainScreen {
                        currentScreen = "setup"
                    }
                    "setup" -> AlarmSetupScreen(
                        alarmHour, alarmMinute, challengeType,
                        onHourChange = { alarmHour = it },
                        onMinuteChange = { alarmMinute = it },
                        onChallengeSelect = { challengeType = it },

                        onSetAlarm = {
                            alarmSet = true
                            currentScreen = "main"
                        }

                    ) //move to default screen
                    "math" -> MathChallengeScreen(onSolved = {
                        currentScreen = "main"
                    })
                }
            }
        }

    }

}
//DEFAULT SCREEN DISPLAYING TIME
@Composable
fun MainScreen(onSetAlarmClick: () -> Unit) {

    // holds current time and updates every second
    var currentTime by remember { mutableStateOf(getCurrentTime()) }


    LaunchedEffect(Unit) {
        while (true) {
            delay(1000)
            currentTime = getCurrentTime()
        }
    }

    DisposableEffect(Unit) {
        Log.d("ComposeLifecycle", "MainScreen: Entered composition")
        onDispose {
            Log.d("ComposeLifecycle", "MainScreen: Left composition")
        }
    }
    //----------------------------MAIN SCREEN UI-----------------------
    Column(
        modifier = Modifier

            .fillMaxSize()
            .padding(32.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("Current Time: $currentTime", fontSize = 32.sp)
        Spacer(modifier = Modifier.height(24.dp))
        Button(onClick = onSetAlarmClick) {
            Text("Set Alarm")
        }
    }
}
//--------------------MAIN SCREEN UI------------------------------




//SCREEN FOR SETTING ALARM TIME
@Composable
fun AlarmSetupScreen(

    hour: String,
    minute: String,
    challengeType: String,
    onHourChange: (String) -> Unit,
    onMinuteChange: (String) -> Unit,
    onChallengeSelect: (String) -> Unit,
    onSetAlarm: () -> Unit
) {
    DisposableEffect(Unit) {

        Log.d("ComposeLifecycle", "AlarmSetupScreen: Entered composition")
        onDispose {
            Log.d("ComposeLifecycle", "AlarmSetupScreen: Left composition")
        }
    }

    val hours = (0..23).map { it.toString().padStart(2, '0') }

    val minutes = (0..59).map { it.toString().padStart(2, '0') }


    //-------------------SET UP SCREEN UI----------------------------------
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(32.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("Set Alarm Time", fontSize = 24.sp)
        Row {
            DropdownSelector("Hour", hour, hours, onHourChange)
            Spacer(modifier = Modifier.width(16.dp))
            DropdownSelector("Minute", minute, minutes, onMinuteChange)
        }
        Spacer(modifier = Modifier.height(16.dp))
        Text("Choose Challenge")
        Row {
            RadioButton(selected = challengeType == "math", onClick = { onChallengeSelect("math") })
            Text("Math")
            Spacer(modifier = Modifier.width(16.dp))
            RadioButton(selected = challengeType == "qr", onClick = { onChallengeSelect("qr") })
            Text("QR Code")
        }
        Spacer(modifier = Modifier.height(24.dp))
        Button(onClick = onSetAlarm) {
            Text("Set Alarm")
        }
    }
}
//------------------SET UP SCREEN UI----------------------------------------------------


//Drop down menu for math screen
@Composable
fun DropdownSelector(
    label: String,
    selectedValue: String,
    items: List<String>,
    onValueSelected: (String) -> Unit
) {
    DisposableEffect(Unit) {
        Log.d("ComposeLifecycle", "DropdownSelector ($label): Entered composition")
        onDispose {
            Log.d("ComposeLifecycle", "DropdownSelector ($label): Left composition")
        }
    }

    var expanded by remember { mutableStateOf(false) }
    //--------------------------DROP DOWN UI---------------------------
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(label)
        Box {
            Button(onClick = { expanded = true }) {
                Text(selectedValue)
            }
            DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                items.forEach { value ->
                    DropdownMenuItem(onClick = {
                        onValueSelected(value)
                        expanded = false
                    }, text = { Text(value) })
                }
            }
        }
    }
//-----------------DROP DOWN UI--------------------------------------
}



//SCREEN FOR MATH PROBLEM
@Composable
fun MathChallengeScreen(onSolved: () -> Unit) {
    DisposableEffect(Unit) {
        Log.d("ComposeLifecycle", "MathChallengeScreen: Entered composition")
        onDispose {
            Log.d("ComposeLifecycle", "MathChallengeScreen: Left composition")
        }
    }
    //Make Alarm sound go off on repeat
    val context = LocalContext.current
    val mediaPlayer = remember {
        MediaPlayer.create(context, R.raw.alarm_sound).apply {
            isLooping = true
            start()
        }
    }
        //stops alarm when screen is left
    DisposableEffect(Unit) {
        Log.d("ComposeLifecycle", "MathChallengeScreen: Entered composition")

        onDispose {
            Log.d("ComposeLifecycle", "MathChallengeScreen: Left composition")
            mediaPlayer.stop()
            mediaPlayer.release()
        }
    }
    //random math problem with 3 variables
    val a = remember { (1..9).random() }
    val b = remember { (1..9).random() }
    val c = remember { (10..99).random() }
    val answer = remember { a * b + c }

    var userInput by remember { mutableStateOf("") }
    var isCorrect by remember { mutableStateOf(false) }

    //--------------UI---------------------------------------------
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(32.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("Solve: $a * $b + $c", fontSize = 24.sp)
        Spacer(modifier = Modifier.height(16.dp))
        OutlinedTextField(
            value = userInput,
            onValueChange = { userInput = it },
            label = { Text("Your Answer") }
        )
        Spacer(modifier = Modifier.height(16.dp))
        Button(onClick = {
            if (userInput.toIntOrNull() == answer) {
                isCorrect = true
                onSolved()
            }
        }) {
            Text("Submit")
        }
        if (isCorrect) {
            Text("Correct! Returning to Main Screen.", fontSize = 16.sp)
        }
    }
 //---------------UI------------------------------------------------
}

//gets the current time
fun getCurrentTime(): String {
    val sdf = SimpleDateFormat("HH:mm:ss", Locale.getDefault())
    return sdf.format(Date())
}
